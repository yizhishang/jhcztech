package com.jhcz.plat.template;

import com.jhcz.plat.domain.Catalog;

/**
 * 描述:
 * 版权:	 Copyright (c) 2009
 * 公司:	 285206405@qq.com
 * 作者:	 liwei
 * 版本:	 1.0
 * 创建日期: Mar 29, 2010
 * 创建时间: 9:24:58 PM
 */
public interface PeculiarTemplate
{
	
	public void run(Catalog catalog);
}
