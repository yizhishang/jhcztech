package com.jhcz.common.action;

public class TestAction extends CommonAction
{
    
    @Override
    public String getTablename()
    {
        return "TEST_EXCEL";
    }
    
}
