package com.jhcz.timerengine;


public interface TaskBuilder
{
    public abstract TaskEntry builderTask();
}
