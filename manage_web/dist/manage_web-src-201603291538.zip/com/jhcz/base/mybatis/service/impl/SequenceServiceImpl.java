package com.jhcz.base.mybatis.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.jhcz.base.mybatis.dao.SequenceDao;
import com.jhcz.base.mybatis.service.SequenceService;
import com.jhcz.base.pojo.Sequence;

@Service
public class SequenceServiceImpl implements SequenceService
{
	@Resource
	SequenceDao sequenceDao;
	
	@Override
	public Sequence getNextSequence(String name)
	{
		
		return sequenceDao.getNextSequence(name);
	}
	
	public String getNextSequence(String id, String name)
	{
		return null;
	}
	
}
