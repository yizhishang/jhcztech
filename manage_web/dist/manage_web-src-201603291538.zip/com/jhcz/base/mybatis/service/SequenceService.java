package com.jhcz.base.mybatis.service;

import com.jhcz.base.pojo.Sequence;


public interface SequenceService
{
	/**
	* 获得缺省数据源上的表的SEQUENCE
	* @param name 对应SEQUENCE的名称
	* @return
	*/
	public Sequence getNextSequence(String name);
	
	/**
	* 获得特定数据源上的表的SEQUENCE
	* @param id   对应datasource.xml文件中的数据源ID
	* @param name 对应SEQUENCE的名称
	* @return
	*/
	public String getNextSequence(String id, String name);
}
